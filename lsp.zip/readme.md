# Micro Live Song Player

## Introduction
一个 BiliBili 弹幕点歌机！

……那是什么？

是指`允许用户在Bilibili直播间内使用弹幕指令点歌的程序`！

<!-- 什么，还是没有听懂？那么[看个视频了解一下]()！ -->

## UI展示
嗯……我自认为还是做的蛮好看的啦

<small>~~本来打算做毛玻璃但是OBS不允许~~</small>

